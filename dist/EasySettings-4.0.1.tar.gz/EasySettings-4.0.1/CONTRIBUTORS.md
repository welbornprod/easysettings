# Contributors

These are the people that have contributed to EasySettings.
File an [issue](https://github.com/welbornprod/easysettings/issues) or create
a [pull request](https://github.com/welbornprod/easysettings/pulls) if you
have any questions or suggestions.

## Thank you:

- [cjwelborn](https://github.com/cjwelborn)
- [ziima](https://github.com/ziima)
