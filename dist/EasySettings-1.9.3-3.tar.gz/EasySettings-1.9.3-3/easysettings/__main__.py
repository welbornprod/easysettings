# Helper for running EasySettings with python -m.
from easysettings import test_run
test_run()
