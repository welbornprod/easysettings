# Helper for running EasySettings with python -m.
import sys
from .easy_settings import _print_help
_print_help()
sys.exit(1)
